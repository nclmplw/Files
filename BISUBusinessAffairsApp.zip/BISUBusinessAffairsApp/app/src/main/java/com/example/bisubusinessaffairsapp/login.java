package com.example.bisubusinessaffairsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class login extends AppCompatActivity {
    EditText uname, pword;
    Button loginc, signupc;
    ImageButton admnstrtr;
    boolean passwordVisible = false;

    DatabaseOperations dbo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        uname=(EditText) findViewById(R.id.unamecustomer);
        pword=(EditText) findViewById(R.id.pworddcustomer);
        loginc=(Button) findViewById(R.id.login);
        signupc=(Button) findViewById(R.id.signupcustomer);
        admnstrtr=(ImageButton) findViewById(R.id.admnstrtr);
        dbo=new DatabaseOperations(this);

        pword.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int right=2;
                if(motionEvent.getAction()== MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= pword.getRight() - pword.getCompoundDrawables()[right].getBounds().width()) {
                        int selection = pword.getSelectionEnd();
                        if (passwordVisible) {
                            pword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            pword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = false;
                        } else {
                            pword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_24, 0);
                            pword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = true;
                        }
                        pword.setSelection(selection);
                        return true;
                    }
                }
                return false;
            }
        });

        loginc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (uname.getText().toString().equals("") || pword.getText().toString().equals("")) {
                    showError(uname,"Enter username");
                } else {
                    Boolean checkusername = dbo.checkusername(uname.getText().toString());
                    Boolean checkpassword = dbo.checkpassword(pword.getText().toString());

                    if (checkusername == true && checkpassword == true) {
                        Intent intent = new Intent(login.this, home.class);
                        intent.putExtra("Username", uname.getText().toString());
                        startActivity(intent);
                        uname.setText("");
                        pword.setText("");
                    } else {
                        showError(uname,"Invalid Username and Password");
                        uname.setText("");
                        pword.setText("");
                    }
                }
            }

            private void showError(EditText uname, String enter_username) {
                uname.setError(enter_username);
            }
        });

        signupc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signup= new Intent(login.this, signupcustomer.class);
                startActivity(signup);
            }
        });

        admnstrtr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login= new Intent(login.this, adminlogin.class);
                startActivity(login);
            }
        });
    }
}