package com.example.bisubusinessaffairsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class signupcustomer extends AppCompatActivity {
    EditText fnamecustomer, lnamecustomer, coursecustomer, unamecustomer, cpssword, pssword;
    Button loginbck, createcust;
    TextView txterror;
    boolean passwordVisible;
    DatabaseOperations dbo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupcustomer);
        fnamecustomer = (EditText) findViewById(R.id.fnamecustomer);
        lnamecustomer = (EditText) findViewById(R.id.lnamecustomer);
        coursecustomer = (EditText) findViewById(R.id.coursecustomer);
        unamecustomer = (EditText) findViewById(R.id.unamecustomer);
        cpssword = (EditText) findViewById(R.id.cpworddcustomer);
        pssword = (EditText) findViewById(R.id.pworddcustomer);
        createcust = (Button) findViewById(R.id.createcustomer);
        loginbck=(Button) findViewById(R.id.loginbck);
        txterror=(TextView) findViewById(R.id.error);
        dbo = new DatabaseOperations(this);

        createcust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fnamecustomer.getText().toString().equals("")&lnamecustomer.getText().toString().equals("")&coursecustomer.getText().toString().equals("")&unamecustomer.getText().toString().equals("")&pssword.getText().toString().equals("")&cpssword.getText().toString().equals("")){
                    txterror.setText("Please fill out the information below.");
                    txterror.setTextColor(Color.rgb(255,0,0));
                }else{
                    if(cpssword.getText().toString() != pssword.getText().toString()){
                        txterror.setText("Password didn't matched.");
                        txterror.setTextColor(Color.rgb(255,0,0));
                        pssword.setText("");
                        cpssword.setText("");
                    }
                    else{
                        txterror.setText("");
                        dbo.insertCustomer(fnamecustomer.getText().toString(), lnamecustomer.getText().toString(), coursecustomer.getText().toString(),unamecustomer.getText().toString(),pssword.getText().toString());
                        Intent login = new Intent(signupcustomer.this,login.class);
                        startActivity(login);
                    }
                }
            }
        });

        pssword.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int right=2;
                if(motionEvent.getAction()== MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= pssword.getRight() - pssword.getCompoundDrawables()[right].getBounds().width()) {
                        int selection = pssword.getSelectionEnd();
                        if (passwordVisible) {
                            pssword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            pssword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = false;
                        } else {
                            pssword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            pssword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = true;
                        }
                        pssword.setSelection(selection);
                        return true;
                    }
                }
                return false;
            }
        });

        loginbck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back= new Intent(signupcustomer.this,login.class);
                startActivity(back);
            }
        });
    }
}