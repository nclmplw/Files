package com.example.bisubusinessaffairsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class customerinfo extends AppCompatActivity {
    TextView idc;
    EditText firstnamec, lastnamec, course, username, password;
    Button update, delete;
    DatabaseOperations dbo;
    ListView listview;
    ArrayAdapter adapter;
    ArrayList<String> getCustomers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customerinfo);
        idc=(TextView) findViewById(R.id.idc);
        firstnamec=(EditText) findViewById(R.id.firstnamec);
        lastnamec=(EditText) findViewById(R.id.lastnamec);
        course=(EditText) findViewById(R.id.course);
        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        update=(Button) findViewById(R.id.update);
        delete=(Button) findViewById(R.id.delete);
        listview=(ListView) findViewById(R.id.listview);
        dbo= new DatabaseOperations(this);
        getCustomers=dbo.getAllCustomer();

        adapter= new ArrayAdapter(this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,getCustomers);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(customerinfo.this, "The Selected Value "+ position, Toast.LENGTH_LONG).show();
                idc.setText(""+getCustomers.get(position));
                String text[] = getCustomers.get(position).split(" | ");
                firstnamec.setText(""+text[1]);
                lastnamec.setText(""+text[2]);
                course.setText(""+text[3]);
                username.setText(""+text[4]);
                password.setText(""+text[5]);
            }
        });
    update.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(firstnamec.getText().toString().equals("")&lastnamec.getText().toString().equals("")&course.getText().toString().equals("")&username.getText().toString().equals("")&password.getText().toString().equals("")){
                showError1(firstnamec,"Enter firstname");
                showError2(lastnamec,"Enter lastname");
                showError3(course,"Enter course");
                showError4(username,"Enter username");
                showError5(password,"Enter password");
            }else{
                dbo.updateCustomer(Integer.valueOf(idc.getText().toString()),firstnamec.getText().toString(),lastnamec.getText().toString(),course.getText().toString(),username.getText().toString(),password.getText().toString());
                firstnamec.setText("");
                lastnamec.setText("");
                course.setText("");
                username.setText("");
                password.setText("");
            }
        }

        private void showError5(EditText password, String enter_password) {
            password.setError(enter_password);
        }

        private void showError4(EditText username, String enter_username) {
            username.setError(enter_username);
        }

        private void showError3(EditText course, String enter_course) {
            course.setError(enter_course);
        }

        private void showError2(EditText lastnamec, String enter_lastname) {
            lastnamec.setError(enter_lastname);
        }

        private void showError1(EditText firstnamec, String enter_firstname) {
            firstnamec.setError(enter_firstname);
        }

    });

    delete.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(dbo.deleteCustomer(Integer.valueOf(idc.getText().toString()))){
                Toast.makeText(customerinfo.this, "DELETED SUCCESSFULLY!", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(customerinfo.this, "DELETE FAILED!", Toast.LENGTH_SHORT).show();
            }
        }
    });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.home:
                Intent home= new Intent(this, home.class);
                startActivity(home);
                break;

            case R.id.product:
                Intent product=new Intent(this, product.class);
                startActivity(product);
                break;

            case R.id.shop:
                Intent shop= new Intent(this, shop.class);
                startActivity(shop);
                break;

            case R.id.admin:
                break;

            case R.id.customerinfo:
                Intent customerinfo=new Intent(this, admin.class);
                startActivity(customerinfo);
                break;

            case R.id.admininfo:
                Intent admininfo=new Intent(this, admin1.class);
                startActivity(admininfo);
                break;

            case R.id.productinfo:
                Intent productinfo=new Intent(this, admin2.class);
                startActivity(productinfo);
                break;

            case R.id.purchasedinfo:
                Intent purchasedinfo=new Intent(this,admin3.class);
                startActivity(purchasedinfo);
                break;

            case R.id.aboutus:
                Intent aboutus=new Intent(this,aboutus.class);
                startActivity(aboutus);
                break;
        }
        return super.onOptionsItemSelected(item);

    }
}