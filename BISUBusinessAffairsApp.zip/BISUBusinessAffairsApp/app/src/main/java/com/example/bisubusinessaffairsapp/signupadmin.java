package com.example.bisubusinessaffairsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class signupadmin extends AppCompatActivity {
    EditText fnameadmin, lnameadmin, unameadmin, apword, pssword;
    Button loginbck, createad;
    TextView txterror;
    boolean passwordVisible;
    DatabaseOperations dbo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupadmin);
        fnameadmin = (EditText) findViewById(R.id.fnameadmin);
        lnameadmin = (EditText) findViewById(R.id.lnameadmin);
        unameadmin = (EditText) findViewById(R.id.unameadmin);
        apword = (EditText) findViewById(R.id.apworddadmin);
        pssword = (EditText) findViewById(R.id.pworddadmin);
        createad = (Button) findViewById(R.id.createadmin);
        loginbck=(Button) findViewById(R.id.loginbck);
        txterror=(TextView) findViewById(R.id.error);
        dbo = new DatabaseOperations(this);

        createad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fnameadmin.getText().toString().equals("")&lnameadmin.getText().toString().equals("")&unameadmin.getText().toString().equals("")&pssword.getText().toString().equals("")&apword.getText().toString().equals("")){
                    txterror.setText("Please fill out the information below.");
                    txterror.setTextColor(Color.rgb(255,0,0));
                }else{
                    if(apword.getText().toString() == pssword.getText().toString()){
                        txterror.setText("");
                        dbo.insertAdmin(fnameadmin.getText().toString(), lnameadmin.getText().toString(), unameadmin.getText().toString(),pssword.getText().toString());
                        Intent login = new Intent(signupadmin.this,adminlogin.class);
                        startActivity(login);
                    }
                    else{
                        txterror.setText("Password didn't matched.");
                        txterror.setTextColor(Color.rgb(255,0,0));
                        pssword.setText("");
                        apword.setText("");
                    }
                }
            }
        });

        pssword.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int right=2;
                if(motionEvent.getAction()== MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= pssword.getRight() - pssword.getCompoundDrawables()[right].getBounds().width()) {
                        int selection = pssword.getSelectionEnd();
                        if (passwordVisible) {
                            pssword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            pssword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = false;
                        } else {
                            pssword.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            pssword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = true;
                        }
                        pssword.setSelection(selection);
                        return true;
                    }
                }
                return false;
            }
        });

        loginbck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back= new Intent(signupadmin.this,login.class);
                startActivity(back);
            }
        });
    }
}