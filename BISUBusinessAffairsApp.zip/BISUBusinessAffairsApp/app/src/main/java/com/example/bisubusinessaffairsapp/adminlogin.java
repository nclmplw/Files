package com.example.bisubusinessaffairsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class adminlogin extends AppCompatActivity {
    EditText username, password;
    Button logina, signupa;
    ImageButton cstmr;
    boolean passwordVisible = false;
    DatabaseOperations dbo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);
        username=(EditText) findViewById(R.id.unameadmin);
        password=(EditText) findViewById(R.id.pworddadmin);
        logina=(Button) findViewById(R.id.loginadmin);
        signupa=(Button) findViewById(R.id.signupadmin);
        cstmr=(ImageButton) findViewById(R.id.cstomer);
        dbo=new DatabaseOperations(this);

        password.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int right=2;
                if(motionEvent.getAction()== MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= password.getRight() - password.getCompoundDrawables()[right].getBounds().width()) {
                        int selection = password.getSelectionEnd();
                        if (passwordVisible) {
                            password.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = false;
                        } else {
                            password.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.password, 0, R.drawable.ic_baseline_visibility_24, 0);
                            password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible = true;
                        }
                        password.setSelection(selection);
                        return true;
                    }
                }
                return false;
            }
        });

        logina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().equals("") || password.getText().toString().equals("")) {
                    showError(username,"Enter username");
                } else {
                    Boolean checkusername = dbo.checkusername(username.getText().toString());
                    Boolean checkpassword = dbo.checkpassword(password.getText().toString());

                    if (checkusername == true && checkpassword == true) {
                        Intent intent = new Intent(adminlogin.this, home.class);
                        intent.putExtra("Username", username.getText().toString());
                        startActivity(intent);
                        username.setText("");
                        password.setText("");
                    } else {
                        showError(username,"Invalid Username and Password");
                        username.setText("");
                        password.setText("");
                    }
                }
            }

            private void showError(EditText username, String invalid_username_and_password) {
                username.setError(invalid_username_and_password);
            }

        });

        signupa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signup= new Intent(adminlogin.this, signupadmin.class);
                startActivity(signup);
            }
        });

        cstmr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login= new Intent(adminlogin.this, login.class);
                startActivity(login);
            }
        });
    }
}